# Memory Index

- [Vercel CLI deploy verification](vercel-cli-deploy-verification.md) — CLI + VERCEL_TOKEN set up so Claude can confirm deploys without the dashboard
