---
name: vercel-cli-deploy-verification
description: Vercel CLI is installed and token-authed so Claude can verify Spiderweb deploys without the dashboard
metadata:
  type: reference
---

Vercel CLI (v54.21.1+) is installed globally on Brian's machine. A Vercel access token is saved as a **User-scope env var `VERCEL_TOKEN`** (a fresh session's shell inherits it; do NOT store the token value in any file). Auth identity: `bdhicks83-ui`. Project is `human-bloom/spiderweb`; permanent production alias is `spiderweb-nine.vercel.app` (see [[spiderweb-architecture]] golden rules).

To verify a deploy after a push: `vercel ls spiderweb --token $env:VERCEL_TOKEN` (newest row = latest), then `vercel inspect <url> --token $env:VERCEL_TOKEN` and check the `Aliases` block includes `spiderweb-nine.vercel.app` + status is `● Ready`. If `VERCEL_TOKEN` is empty in a shell, pass the token inline. This replaces the manual "open the dashboard" step in [[deployment-workflow]].
